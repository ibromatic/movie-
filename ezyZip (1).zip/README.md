# Backend (Node + Express + MongoDB)

## Setup
1. Copy `.env.example` to `.env` and fill values.
2. Install deps: `npm install`
3. Run dev: `npm run dev`

## Routes (prefix `/api`)
- `POST /auth/register` `{name,email,password}`
- `POST /auth/login` `{email,password}` → `{token}`
- `GET /auth/me` (Bearer token)

- `GET /movies/search?query=batman`
- `GET /movies/trending`
- `GET /movies/:id`

- `POST /movies/me/favorites` `{tmdbId}` (auth)
- `GET /movies/me/favorites` (auth)
- `DELETE /movies/me/favorites/:tmdbId` (auth)

- `POST /movies/me/watchlist` `{tmdbId}` (auth)
- `GET /movies/me/watchlist` (auth)
- `DELETE /movies/me/watchlist/:tmdbId` (auth)

- `POST /movies/me/reviews` `{tmdbId, rating, review}` (auth)
- `GET /movies/me/reviews` (auth)
